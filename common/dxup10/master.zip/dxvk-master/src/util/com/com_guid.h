#pragma once

#include <ostream>
#include <iomanip>

#include "com_include.h"

std::ostream& operator << (std::ostream& os, REFIID guid);
